package com.santanderuk.corinthian.hub.heartbeat.functional;

import com.jayway.restassured.response.Response;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

@ActiveProfiles("local")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthUrlz;

    @Before
    public void setup() {
        healthUrl = String.format("http://localhost:%s/heart-beat-service/health", serverPort);
        healthUrlz = String.format("http://localhost:%s/heart-beat-service/healthz", serverPort);
    }

    @Test
    public void customHealthCheckReturnsUp() throws Exception {

        Response res =
                given().
                        when().
                        get(healthUrl).
                        then().
                        statusCode(200).extract().response();

        assertEquals(res.asString(),"Up");

    }

    @Test
    public void customHealthzCheckReturnsUp() throws Exception {

        Response res =
                given().
                        when().
                        get(healthUrlz).
                        then().
                        statusCode(200).extract().response();

        assertEquals(res.asString(),"Up");

    }

}
