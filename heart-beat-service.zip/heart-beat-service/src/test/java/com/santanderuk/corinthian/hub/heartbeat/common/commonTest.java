package com.santanderuk.corinthian.hub.heartbeat.common;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class commonTest {
    @Test
    public void getRegionConvertsToString() {
        RegionResponse response = new RegionResponse();
        response.setCode("theCode");
        response.setMessage("the message");
        response.setRegion(Regions.A);
        assertEquals("string is not as expected", "{\"code\":\"theCode\",\"message\":\"the message\",\"region\":\"A\"}", response.toString());
    }
}
