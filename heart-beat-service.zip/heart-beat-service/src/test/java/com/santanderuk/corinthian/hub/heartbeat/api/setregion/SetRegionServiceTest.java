package com.santanderuk.corinthian.hub.heartbeat.api.setregion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import com.santanderuk.corinthian.hub.heartbeat.common.RedisConnector;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static com.santanderuk.corinthian.hub.heartbeat.common.Regions.*;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.springframework.http.HttpStatus.OK;

@RunWith(MockitoJUnitRunner.class)
public class SetRegionServiceTest {

    @Mock
    private RedisConnector mockRedisConnector;

    private SetRegionService setRegionService;

    @Before
    public void setUp() {

        setRegionService = new SetRegionService(mockRedisConnector);
    }

    @Test
    public void testweSetRegionA() {


        ResponseEntity<RegionResponse> response = setRegionService.setRegion(A);
        RegionResponse body = response.getBody();

        assertThat(response.getStatusCode(), equalTo(OK));
        assertThat(body.getMessage(), equalTo("Region A set up correctly"));
        assertThat(body.getCode(), equalTo("SET_REGION_OK"));
        assertThat(body.getRegion(), equalTo(A));

    }

    @Test
    public void testweGetRegionW() {

        ResponseEntity<RegionResponse> response = setRegionService.setRegion(W);
        RegionResponse body = response.getBody();

        assertThat(response.getStatusCode(), equalTo(OK));
        assertThat(body.getMessage(), equalTo("Region W set up correctly"));
        assertThat(body.getCode(), equalTo("SET_REGION_OK"));
        assertThat(body.getRegion(), equalTo(W));

    }

    @Test
    public void testweGetRegionX() {

        ResponseEntity<RegionResponse> response = setRegionService.setRegion(X);
        RegionResponse body = response.getBody();

        assertThat(response.getStatusCode(), equalTo(OK));
        assertThat(body.getMessage(), equalTo("Region X set up correctly"));
        assertThat(body.getCode(), equalTo("SET_REGION_OK"));
        assertThat(body.getRegion(), equalTo(X));

    }

}
