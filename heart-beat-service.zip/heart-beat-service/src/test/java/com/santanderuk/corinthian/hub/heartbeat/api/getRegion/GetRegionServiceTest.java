package com.santanderuk.corinthian.hub.heartbeat.api.getRegion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import com.santanderuk.corinthian.hub.heartbeat.common.RedisConnector;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static com.santanderuk.corinthian.hub.heartbeat.common.Regions.*;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.*;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.OK;


@RunWith(MockitoJUnitRunner.class)
public class GetRegionServiceTest {

    @Mock
    private RedisConnector mockRedisConnector;

    @InjectMocks
    private GetRegionService getRegionService;

    @Test
    public void testWeGetRegionA() {

        Mockito.when(mockRedisConnector.getValue("RegionUp")).thenReturn(A);

        ResponseEntity<RegionResponse> response = getRegionService.getRegion();
        RegionResponse body = response.getBody();

        assertEquals(OK, response.getStatusCode());
        assertEquals("Region available is A", body.getMessage());
        assertEquals("GET_REGION_OK", body.getCode());
        assertEquals(A, body.getRegion());
    }

    @Test
    public void testWeGetRegionW() {

        Mockito.when(mockRedisConnector.getValue("RegionUp")).thenReturn(W);

        ResponseEntity<RegionResponse> response = getRegionService.getRegion();
        RegionResponse body = response.getBody();

        assertEquals(OK, response.getStatusCode());
        assertEquals("Region available is W", body.getMessage());
        assertEquals("GET_REGION_OK", body.getCode());
        assertEquals(W, body.getRegion());

    }

    @Test
    public void testWeGetRegionX() {

        Mockito.when(mockRedisConnector.getValue("RegionUp")).thenReturn(X);

        ResponseEntity<RegionResponse> response = getRegionService.getRegion();
        RegionResponse body = response.getBody();

        assertEquals(OK, response.getStatusCode());
        assertEquals("Region available is X", body.getMessage());
        assertEquals("GET_REGION_OK", body.getCode());
        assertEquals(X, body.getRegion());

    }

    @Test
    public void testWeGetException() {

        Mockito.when(mockRedisConnector.getValue("RegionUp")).thenReturn(null);

        ResponseEntity<RegionResponse> response = getRegionService.getRegion();
        RegionResponse body = response.getBody();

        assertEquals(INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Value read in redis is not A , W or X", body.getMessage());
        assertEquals("GET_REGION_KO_INCORRECT_VALUE", body.getCode());
        assertNull(body.getRegion());

    }

}
