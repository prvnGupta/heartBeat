package com.santanderuk.corinthian.hub.heartbeat.functional;

import com.santanderuk.corinthian.hub.heartbeat.HeartBeatApplication;
import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(classes = HeartBeatApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HeartBeatFunctionalTest {

    private String heartBeatSetRegionUrl;
    private String heartBeatGetRegionUrl;

    @LocalServerPort
    protected String serverPort;

    @Before
    public void setup() {

        heartBeatGetRegionUrl = String.format("http://localhost:%s/heart-beat-service/get-region", serverPort);
        heartBeatSetRegionUrl = String.format("http://localhost:%s/heart-beat-service/set-region", serverPort);
    }

    @After
    public void tearDown() {
        given().
                when().
                put(heartBeatSetRegionUrl + "/A");

        log.info("Region set back to A after test");
    }

    @Test
    public void testSetGetRegionA() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/A").
                then().
                statusCode(200).
                body("code", equalTo("SET_REGION_OK"),
                        "message", equalTo("Region A set up correctly"),
                        "region", equalTo("A"));

        given().
                when().
                get(heartBeatGetRegionUrl).
                then().
                statusCode(200).
                body("code", equalTo("GET_REGION_OK"),
                        "message", equalTo("Region available is A"),
                        "region", equalTo("A"));
    }

    @Test
    public void testSetGetRegionALowerCase() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/a").
                then().
                statusCode(200).
                body("code", equalTo("SET_REGION_OK"),
                        "message", equalTo("Region A set up correctly"),
                        "region", equalTo("A"));

        given().
                when().
                get(heartBeatGetRegionUrl).
                then().
                statusCode(200).
                body("code", equalTo("GET_REGION_OK"),
                        "message", equalTo("Region available is A"),
                        "region", equalTo("A"));
    }

    @Test
    public void testSetGetRegionX() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/X").
                then().
                statusCode(200).
                body("code", equalTo("SET_REGION_OK"),
                        "message", equalTo("Region X set up correctly"),
                        "region", equalTo("X"));

        given().
                when().
                get(heartBeatGetRegionUrl).
                then().
                statusCode(200).
                body("code", equalTo("GET_REGION_OK"),
                        "message", equalTo("Region available is X"),
                        "region", equalTo("X"));
    }

    @Test
    public void testSetGetRegionW() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/W").
                then().
                statusCode(200).
                body("code", equalTo("SET_REGION_OK"),
                        "message", equalTo("Region W set up correctly"),
                        "region", equalTo("W"));

        given().
                when().
                get(heartBeatGetRegionUrl).
                then().
                statusCode(200).
                body("code", equalTo("GET_REGION_OK"),
                        "message", equalTo("Region available is W"),
                        "region", equalTo("W"));
    }

    @Test
    public void testSetWrongRegion() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/R").
                then().
                statusCode(400);
    }

    @Test
    public void testSetWrongRegionInLowerCase() {

        given().
                when().
                put(heartBeatSetRegionUrl + "/h").
                then().
                statusCode(400);
    }

}
