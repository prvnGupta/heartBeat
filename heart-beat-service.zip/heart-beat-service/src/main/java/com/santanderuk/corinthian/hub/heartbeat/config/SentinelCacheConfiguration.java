package com.santanderuk.corinthian.hub.heartbeat.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

@Configuration
@ConditionalOnProperty(name = "redis.sentinel.enabled", havingValue = "true")
@Profile({"!test"})
public class SentinelCacheConfiguration {

    @Value("${spring.redis.sentinel.master}")
    private String sentinelMaster;

    @Value("${spring.redis.sentinel.nodes}")
    private String sentinelNodes;

    @Value("${spring.redis.password}")
    private String redisPassword;

    @Bean
    public RedisConnectionFactory lettuceConnectionFactoryWithRedisSentinelConfiguration() {
        RedisSentinelConfiguration sentinelConfig = new RedisSentinelConfiguration();
        sentinelConfig.master(sentinelMaster);
        String[] sentinels = sentinelNodes.split(",");

        for (String sentinel : sentinels) {
            String[] sentinelInfo = sentinel.split(":");
            sentinelConfig.sentinel(sentinelInfo[0], Integer.valueOf(sentinelInfo[1]));
        }
        sentinelConfig.setPassword(redisPassword);
        return new LettuceConnectionFactory(sentinelConfig);
    }

    @Bean
    RedisTemplate<String, Object> redisTemplate() {
        final RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
        template.setConnectionFactory(lettuceConnectionFactoryWithRedisSentinelConfiguration());
        return template;
    }
}
