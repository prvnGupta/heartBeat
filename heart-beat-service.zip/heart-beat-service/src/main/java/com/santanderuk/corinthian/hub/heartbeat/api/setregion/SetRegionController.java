package com.santanderuk.corinthian.hub.heartbeat.api.setregion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import com.santanderuk.corinthian.hub.heartbeat.common.Regions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class SetRegionController {

    private final SetRegionService setRegionService;

    @Autowired
    public SetRegionController(SetRegionService setRegionService) {
        this.setRegionService = setRegionService;
    }

    @RequestMapping(
            value = "/set-region/{region}",
            method = RequestMethod.PUT,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<RegionResponse> setRegion(@Valid @PathVariable("region") String region) {

        Regions regionEnum = Regions.toRegion(region);

        return setRegionService.setRegion(regionEnum);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleUnknownRegion(){
        return new ResponseEntity<>("Unknown Region", HttpStatus.BAD_REQUEST);
    }
}


