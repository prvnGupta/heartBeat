package com.santanderuk.corinthian.hub.heartbeat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Created by C02229411 on 08/03/2017. PROJECT: HeartBeat
 */
@EnableScheduling
@SpringBootApplication
public class HeartBeatApplication {

    public static void main(String... args) throws Exception {
        SpringApplication.run(HeartBeatApplication.class, args);
    }
}

