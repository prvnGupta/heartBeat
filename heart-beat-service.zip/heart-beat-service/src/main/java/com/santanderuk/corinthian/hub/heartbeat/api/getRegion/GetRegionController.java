package com.santanderuk.corinthian.hub.heartbeat.api.getRegion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class GetRegionController {

    private final GetRegionService getRegionService;

    @Autowired
    public GetRegionController(GetRegionService getRegionService) {
        this.getRegionService = getRegionService;
    }

    @RequestMapping(
            value = "/get-region",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<RegionResponse> getRegion() {
        log.debug("GetRegion request received");
        return getRegionService.getRegion();
    }
}
