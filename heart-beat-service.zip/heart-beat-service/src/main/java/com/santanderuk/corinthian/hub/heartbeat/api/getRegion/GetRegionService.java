package com.santanderuk.corinthian.hub.heartbeat.api.getRegion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import com.santanderuk.corinthian.hub.heartbeat.common.RedisConnector;
import com.santanderuk.corinthian.hub.heartbeat.common.Regions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import static com.santanderuk.corinthian.hub.heartbeat.common.Regions.*;

@Service
@Slf4j
public class GetRegionService {

    private RedisConnector redisConnector;

    @Autowired
    public GetRegionService(RedisConnector redisConnector) {
        this.redisConnector = redisConnector;
    }

    public ResponseEntity<RegionResponse> getRegion() {
        Regions regionUp = redisConnector.getValue("RegionUp");

        if (regionUp == A || regionUp == W || regionUp == X) {
            log.debug("Connection to redis successful. Region Available: {}", regionUp);
            return new ResponseEntity<>(new RegionResponse("GET_REGION_OK", "Region available is " + regionUp, regionUp), HttpStatus.OK);
        } else {
            log.error("VALUE READ IN REDIS NOT VALID. VALUE: {}", regionUp);
            return new ResponseEntity<>(new RegionResponse("GET_REGION_KO_INCORRECT_VALUE", "Value read in redis is not A , W or X", regionUp),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}


