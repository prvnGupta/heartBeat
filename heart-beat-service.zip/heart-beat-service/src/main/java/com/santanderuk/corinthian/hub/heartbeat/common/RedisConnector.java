package com.santanderuk.corinthian.hub.heartbeat.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RedisConnector {

    private final RedisTemplate<String, Object> redisTemplate;

    @Autowired
    public RedisConnector(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Regions getValue(final String key) {
        return (Regions) redisTemplate.opsForValue().get(key);
    }

    public void setValue(final String key, final Regions value) {
        redisTemplate.opsForValue().set(key, value);
    }
}


