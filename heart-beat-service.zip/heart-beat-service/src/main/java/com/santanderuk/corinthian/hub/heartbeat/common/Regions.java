package com.santanderuk.corinthian.hub.heartbeat.common;

public enum Regions {
    A, W, X;

    public static Regions toRegion(String region) {
        return Regions.valueOf(region.toUpperCase());
    }
}
