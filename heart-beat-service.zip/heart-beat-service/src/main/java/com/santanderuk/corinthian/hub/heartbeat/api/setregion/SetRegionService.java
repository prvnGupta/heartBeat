package com.santanderuk.corinthian.hub.heartbeat.api.setregion;

import com.santanderuk.corinthian.hub.heartbeat.api.io.RegionResponse;
import com.santanderuk.corinthian.hub.heartbeat.common.RedisConnector;
import com.santanderuk.corinthian.hub.heartbeat.common.Regions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class SetRegionService {

    private final RedisConnector redisConnector;

    @Autowired
    public SetRegionService(RedisConnector redisConnector) {
        this.redisConnector = redisConnector;
    }


    public ResponseEntity<RegionResponse> setRegion(Regions region) {

        redisConnector.setValue("RegionUp", region);
        return new ResponseEntity<>(new RegionResponse("SET_REGION_OK", "Region " + region + " set up correctly", region),
                HttpStatus.OK);

    }
}
