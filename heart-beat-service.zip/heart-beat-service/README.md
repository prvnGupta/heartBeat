```
  _____ _____  ______   _    _ _  __
  / ____|  __ \|  ____| | |  | | |/ /
 | (___ | |__) | |__    | |  | | ' / 
  \___ \|  _  /|  __|   | |  | |  <  
  ____) | | \ \| |____  | |__| | . \ 
 |_____/|_|  \_\______|  \____/|_|\_\
```


Description of gitlab repo deployed

1) src -- Reference project source code
2) Dockerfile -- Reference project docker image file
3) Jenkinsfile -- Reference project Jenkinsfile to build jenkins pipeline
4) Jenkinsfile-release -- Reference project Jenkinsfile for release pipeline
5) Pom.xml -- Reference project pom.xml

Project: pre-pipeline-automation/helloworld-spring-boot2-maven
Jenkinsfile-TagRelease -- Releases the Tag commits
Jenkinsfile -- Releases the Pre 
Project: pro-pipeline-automation/helloworld-spring-boot2-maven
Jenkinsfile -- Releases the Pro

 
redis: docker run -d --name redis -p 6379:6379 redis

reference project source code repositories are available at 

https://uk-gitlab.almuk.santanderuk.corp/cicd-pipeline-uk-reference
